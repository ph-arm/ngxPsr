#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  2 13:12:11 2021

@author: parm
"""
import app

if __name__ == '__main__':
    app.main()